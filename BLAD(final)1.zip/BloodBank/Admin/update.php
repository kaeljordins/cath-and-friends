<?php
$first= $mysqli->escape_string($_POST['firstname']);
$last= $mysqli->escape_string($_POST['lastname']);
date_default_timezone_set("Asia/Manila");
$date = date("Y-m-d");
$date_time = date("Y-m-d h:i:sa");
$age= $mysqli->escape_string($_POST['age']);
$gender= $mysqli->escape_string($_POST['gender']);
$contact= $mysqli->escape_string($_POST['contact']);
$birth= $mysqli->escape_string($_POST['birthdate']);
$add= $mysqli->escape_string($_POST['address']);
$email = $mysqli->escape_string($_POST['email']);
$type= $mysqli->escape_string($_POST['type']);
$pass= $mysqli->escape_string($_POST['password']);
$password = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
$hash = $mysqli->escape_string( md5( rand(0,1000) ) );
$count = $mysqli->escape_string($_POST['blood-count']);
$id = $mysqli->escape_string($_POST['edit_id']);

      
    $sql = " UPDATE tbl_users SET Email = '$email', FirstName = '$first', LastName = '$last', Age = '$age', Address = '$add', Birth_date = '$birth', Gender = '$gender', Contact = '$contact' where UserID = '$id'";
   
    if ( $mysqli->query($sql) ){

         echo '<script>alert("Data successfully updated!");
               location.href="\index.php";</script>' ;
    }

    else {
        $_SESSION['message'] = 'Registration failed!';
        header("location: error-register.php");
    }


?>