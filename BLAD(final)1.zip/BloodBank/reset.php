<?php
$email = $mysqli->escape_string($_POST['email']);
$result = $mysqli->query("SELECT * FROM tbl_users where Email = '$email'");
if ($result->num_rows == 0) {
	echo '<script>alert("Account does not exist!");
               location.href="\index.php";</script>';
} else {
	$user = $result->fetch_assoc(); // $user becomes array with user data
	$email = $user['Email'];
    $hash = $user['Hash'];
    $first = $user['FirstName'];
    $last = $user['LastName'];

    $to      = $email;
    $subject = 'Password Reset Link';
    $message_body = '
    Hello '.$first.' '.$last.',

    You have requested password reset!

    Please click this link to reset your password:

    http://localhost/Webdesigns/BloodBank/Resets.php?Email='.$email.'&Hash='.$hash;  

    mail($to, $subject, $message_body);

    echo '<script>alert("Please check your Email for the confirmation link!");
               location.href="\index.php";</script>';
}
 
 ?>