<?php session_start(); require 'db.php';
$firstname = $_SESSION['first'];
$lastname = $_SESSION['last'];
$bloodtype = $_SESSION['type'];
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Blood Bank - <?php echo $firstname.' '.$lastname; ?></title>
	<link rel="shortcut icon" href="image/s.ico" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<?php
if (isset($_POST['search'])) {
	$_SESSION['type'] = $_POST['type'];
	header("location: search.php");
}
elseif (isset($_POST['reset'])) {
	require 'reset.php';
}
elseif (isset($_POST['login'])) {
	require 'login.php';
}
 ?>
<body> 
	<div class="form-container">
		<h1 style="font-size: 40px; color: red;">B<span style="font-size: 30px; color: black;">LOOD</span> I<span style="font-size: 30px; color: black;">NITIAL</span> L<span style="font-size: 30px; color: black;">ETTING</span> A<span style="font-size: 30px; color: black;">ND</span> T<span style="font-size: 30px; color: black;">RANSFER</span></h1>
		<hr>
		<form method="post">
			<h5>Search Blood Type:</h5>
			<div class="col-sm-2">
				<select class="form-control" id="type" name="type">
					<option value="O-">O-</option>
					<option value="O+">O+</option>
					<option value="A-">A-</option>
					<option value="A+">A+</option>
					<option value="B-">B-</option>
					<option value="B+">B+</option>
					<option value="AB-">AB-</option>
					<option value="AB+">AB+</option>
				</select>
			</div>
			<button class="btn btn-primary" name="search" id ="search" style="background-color: #e60000; border: 0; border-radius: 5px;"><span class="glyphicon glyphicon-search"></span> Search</button>
			<h5>Your Blood Type:</h5>
			<div class="col-sm-2">
				<input type="text" readonly value="<?php echo $bloodtype; ?>" style="text-align: center;" >
			</div>
		</form>
		<div class="right-container" style="border: 0;">
			<h3 style="margin-top: -2%;">Welcome, <?php echo $firstname. ' '.$lastname; ?></h3> <br> <br>
			<p style="margin-top: -8%;">Thank you for being part of the Red Cross Family! Hope you can save a lot.</p>
			<button><span class='glyphicon glyphicon-log-out' aria-hidden='true'></span><a href="logout.php" style="text-decoration: none; color: black;"> Logout</a></button>
		</div> <br> <br> <br> <hr>
		<h2 style="color: gray;">NATIONAL CAPITAL REGION</h2>
		<table style="width: 100%; font-family: Calibri;">
			<thead style="font-size: 20px;">
				<tr>
					<th style="text-align: center;" width="208" height="44">CHAPTER</th>
					<th style="text-align: center;" width="208" height="44">TELEPHONE | FAX NO.</th>
					<th style="text-align: center;" width="208" height="44">ADMINISTRATOR ACA/OIC</th>
				</tr>
			</thead>
			<tbody style="font-size: 16px;">
				<tr>
					<td width="190" height="142"><strong style="font-size: 18px;">CALOOCAN CITY</strong> <br>114 7th Ave. East Grace Park Brgy. 105, Caloocan City 1400 <br>caloocan@redcross.org.ph</td>
					<td width="134" style="text-align: center;">Fax # <br> 366-0380 <br> Telephone # <br> 364-5752 <br> 781-4322 <br> 399-0579 <br> 0922-809-1864</td>
					<td style="text-align: center;" width="255">Mr. Roberto R. Dacles<br> Chapter Administrator<br> 0939-5577458<br> 0917-8400969<br> Wireless<br> 781-5647<br> <em><span>roberto.dacles27@gmail.com</a></span></td>
				</tr>
				<tr>
					<td width="190" height="142"><strong style="font-size: 18px;">LAS PIÑAS CITY SUB-CHAPTER</strong> <br>Bernabe Compound Pulanglupa Uno, Las Piñas City (Beside LP District Hosp. & TESDA,Las Pinas) <br>laspinas@redcross.org.ph</td>
					<td width="134" style="text-align: center;">Telephone # <br> 556-7659 <br> 861-9124</td>
					<td style="text-align: center;" width="255">Ms. Mary Rose B. Urbano<br> Officer In Charge<br> 0917-4787705</td>
				</tr>
				<tr>
					<td width="190" height="142"><strong style="font-size: 18px;">MANILA</strong> <br>Gen. Luna corner Victoria Streets Intramuros Manila 1002<br>manila@redcross.org.ph</td>
					<td width="134" style="text-align: center;">Telefax #<br> 527-3595 <br> 527-2161 <br> Direct Line <br> 521-1994</td>
					<td style="text-align: center;" width="255">Mrs.Crisanta C. Cayetano<br> Chapter Administrator<br> 0917-5227044 <br> 527-3594 <br> <em> crisanta.cayetano@redcross.org.ph </em> </td>
				</tr>
				<tr>
					<td width="190" height="142"><strong style="font-size: 18px;">MALABON CITY </strong> <br>Gov. Pascual Brgy. Potrero, Malabon City<br>malabon@redcross.org.ph</td>
					<td width="134" style="text-align: center;">Tel. #<br> 366-6470</td>
					<td style="text-align: center;" width="255">Mrs. Maria Joana A. Rosete<br> Chapter Administrator<br> 0927-250-3995 <br> <em> mariajoana.rosete@redcross.org.ph </em> </td>
				</tr>
				<tr>
					<td width="190" height="142"><strong style="font-size: 18px;">MARIKINA CITY</strong> <br># 2 V. Gomez cor. JP Rizal Street San Roque, Marikina City (in front of OLA and Shoe Museum)<br>marikina@redcross.org.ph</td>
					<td width="134" style="text-align: center;">Tel. #<br> 398-0836</td>
					<td style="text-align: center;" width="255">Ms. Karen S. Loreno<br> Chapter Administrator<br> 0921-3814354 <br> <em> karen.loreno@redcross.org.ph </em> </td>
				</tr>
			</tbody>
		</table>
	</div>
</body>
</html>