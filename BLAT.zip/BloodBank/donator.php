<?php session_start(); require 'db.php';
$firstname = $_SESSION['first'];
$lastname = $_SESSION['last'];
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Blood Bank - <?php echo $firstname.' '.$lastname; ?></title>
	<link rel="shortcut icon" href="image/s.ico" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<?php
if (isset($_POST['search'])) {
	$_SESSION['type'] = $_POST['type'];
	header("location: search.php");
}
elseif (isset($_POST['reset'])) {
	require 'reset.php';
}
elseif (isset($_POST['login'])) {
	require 'login.php';
}
 ?>
<body> 
	<div class="form-container">
		<h1 style="font-size: 40px; color: red;">B<span style="font-size: 30px; color: black;">LOOD</span> I<span style="font-size: 30px; color: black;">NITIAL</span> L<span style="font-size: 30px; color: black;">ETTING</span> A<span style="font-size: 30px; color: black;">ND</span> T<span style="font-size: 30px; color: black;">RANSFER</span></h1>
		<hr>
		<form method="post">
			<h5>Search Blood Type:</h5>
			<div class="col-sm-2">
				<select class="form-control" id="type" name="type">
					<option value="O-">O-</option>
					<option value="O+">O+</option>
					<option value="A-">A-</option>
					<option value="A+">A+</option>
					<option value="B-">B-</option>
					<option value="B+">B+</option>
					<option value="AB-">AB-</option>
					<option value="AB+">AB+</option>
				</select>
			</div>
			<button class="btn btn-primary" name="search" id ="search" style="background-color: #e60000; border: 0; border-radius: 5px;"><span class="glyphicon glyphicon-search"></span> Search</button>
		</form>
		<div class="right-container">
		<form method="post" autocomplete="off">
			<div class="col-sm-8" style="margin-top: -5%; margin-left: -6%;">
				<input type="email" name="email" placeholder="Enter your Email">
			</div>
			<div class="col-sm-8" style="margin-top: -5.5%; float: right; margin-right: -18%;">
				<input type="password" name="password" placeholder="Enter your Password">
			</div>
			<span style="float: left;"><a href="#forgot" data-toggle="modal">Forgot Password?</a></span>
			<button class="btn btn-primary" name="login" id ="login" style="background-color: #e60000; border: 0; border-radius: 5px; margin-top: 5%; width: 50%;"><span class="glyphicon glyphicon-log-in"></span>  Login</button>
		</form>
		</div> <br> <br> <hr style="background-color: gray; height: 1px;">
	</div>

		<div id="forgot" class="modal fade" role="dialog">
	        <div class="modal-dialog modal-lg">
	            <div class="modal-content">
	                <div class="modal-header">
	                    <button type="button" class="close" data-dismiss="modal">&times;</button>
	                    <h4 class="modal-title">Forgot Password</h4>
	                </div>
	                <div class="modal-body">
	                    <form method="post" class="form-horizontal" role="form">
	                        <div class="form-group">
	                            <label class="control-label col-sm-2" for="email">Email:</label>
	                            <div class="col-sm-4">
	                                <input type="email" class="form-control" id="email" name="email" placeholder="Please enter your Email" required>
	                            </div>
	                        </div>
	                </div>
	                <div class="modal-footer">
	                    <button type="submit" class="btn btn-primary" name="reset"><span class="glyphicon glyphicon-plus"></span> Reset</button>
	                    <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
	                </div>
	                            </div>
	                            </form>
	                        </div>
	        </div>
	    </div>



</body>
</html>