<head>
  <title>Please wait a moment.</title>
</head>
<?php
$email = $mysqli->escape_string($_POST['email']);
                      $result = $mysqli->query("SELECT * FROM tbl_users WHERE Email = '$email'");
                      $row = mysqli_fetch_array($result);
                      $count = mysqli_num_rows($result);
                      $usertype = strtolower($row['Role']);
                        if($count > 0) {
                          if (password_verify($_POST['password'], $row['Password'])) {
                            $_SESSION['id'] = $row['UserID'];
                            $_SESSION['email'] = $row['Email'];
                            $_SESSION['first'] = $row['FirstName'];
                            $_SESSION['last'] = $row['LastName'];
                            $_SESSION['Usertype1'] = strtolower($row['Role']);
                            $first = $row['FirstName'];
                            $last = $row['LastName'];
                            //This is how we'll know the user is logged in
                            $_SESSION['logged_in'] = true;
                            if ($usertype == strtolower('Admin')) {
                              echo '<script>alert("Welcome, '.$first.' '.$last.'");
                              location.href="\Admin/index.php";</script>' ;
                            }
                            elseif ($usertype == strtolower('Donator')) {
                                header("location: donator.php");
                             }
                          else {
                            $_SESSION['message'] = "You have entered the wrong password, Please try again!";
                            header("location: error.php");
                          }
                        }
                          else{
                              echo '<script>alert("Please contact our office!");
                              location.href="\index.php";</script>' ;
                          }
                        }
                          ?>