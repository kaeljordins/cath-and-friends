<?php
/* Registration process, inserts user info into the database 
   and sends account confirmation email message
 */
// Set session variables to be used on profile.php page
$_SESSION['email'] = $_POST['email'];
$_SESSION['first'] = $_POST['firstname'];
$_SESSION['last'] = $_POST['lastname'];
$_SESSION['contact'] = $_POST['contact'];

// Escape all $_POST variables to protect against SQL injections
$first= $mysqli->escape_string($_POST['firstname']);
$last= $mysqli->escape_string($_POST['lastname']);
date_default_timezone_set("Asia/Manila");
$date = date("Y-m-d");
$date_time = date("Y-m-d h:i:sa");
$age= $mysqli->escape_string($_POST['age']);
$gender= $mysqli->escape_string($_POST['gender']);
$contact= $mysqli->escape_string($_POST['contact']);
$birth= $mysqli->escape_string($_POST['birthdate']);
$add= $mysqli->escape_string($_POST['address']);
$email = $mysqli->escape_string($_POST['email']);
$type= $mysqli->escape_string($_POST['type']);
$pass= $mysqli->escape_string($_POST['password']);
$password = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
$hash = $mysqli->escape_string( md5( rand(0,1000) ) );
$count = $mysqli->escape_string($_POST['blood-count']);
      
// Check if user with that email already exists
$result = $mysqli->query("SELECT * FROM tbl_users WHERE Email='$email'") or die($mysqli->error());

// We know user email exists if the rows returned are more than 0
if ( $result->num_rows > 0 ) {
    
   echo '<script>alert("Email is already registered!");
               location.href="\index.php";</script>' ;
    
}
else { // Email doesn't already exist in a database, proceed...

    // active is 0 by DEFAULT (no need to include it here)
    $sql = "INSERT INTO tbl_users (Email, FirstName, LastName, Password, Age, BloodType, Address, Birth_date, Gender, Hash, Role, Contact) " 
            . "VALUES ('$email', '$first', '$last', '$password', '$age', '$type', '$add', '$birth', '$gender', '$hash', 'Donator', '$contact')";
    $last_id = 0;

    // Add user to the database
    if ( $mysqli->query($sql) ){
        $last_id = mysqli_insert_id($mysqli);
        $sql1 = "INSERT INTO tbl_history(UserID, Blood_Bag, date_donated) VALUES ('$last_id', '$count', '$date')";

        if ($mysqli->query($sql1)) {

        // Send registration confirmation link (verify.php)
        $to      = $email;
        $subject = 'Account Verification';
        $message_body = '
        Hello '.$first.' '.$last.',

        Thank you for Donating Blood! Your Blood could save many life.

        Please visit our site,
        http://localhost/Webdesigns/BloodBank

        This is your login credentials
        Username: '.$email.'
        Password: '.$pass.'';  

        mail( $to, $subject, $message_body );

         echo '<script>alert("Account successfully created!");
               location.href="\index.php";</script>' ;

           }
    }

    else {
        $_SESSION['message'] = 'Registration failed!';
        header("location: error-register.php");
    }

}
?>