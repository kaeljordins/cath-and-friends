<?php
date_default_timezone_set("Asia/Manila");
$date = date("Y-m-d");
$count = $mysqli->escape_string($_POST['blood-count']);
$id = $mysqli->escape_string($_POST['edit_id']);

      
    $sql = "INSERT INTO tbl_history(UserID, Blood_Bag, date_donated) VALUES ('$id', '$count', '$date')";
   
    if ( $mysqli->query($sql) ){

         echo '<script>alert("Data successfully updated!");
               location.href="\index.php";</script>' ;
    }

    else {
        $_SESSION['message'] = 'Registration failed!';
        header("location: error-register.php");
    }
?>