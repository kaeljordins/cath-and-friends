<head>
	<title>Logging out.</title>
</head>
<?php
  session_start();
    $_SESSION = array();
    session_destroy();
echo '<script>alert("You have been logged out!");
               location.href="\index.php";</script>' ;
?>