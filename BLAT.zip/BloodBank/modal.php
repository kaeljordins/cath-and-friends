 <!--MODAL-->
	   <div id="modal1" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content" style="width: 50%;">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Preferred Age</h4>
                        </div>
                        <div class="modal-body">
                            <form method="post" class="form-horizontal" role="form">    
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="age">Age:</label>       
                                    <div class="col-sm-4">
                                    	<select class="form-control" id="age" name="age" autofocus required style="width: ">
                                    		<option value="16-20">16 to 20</option>
                                    		<option value="21-30">21 to 30</option>
                                    		<option value="31-40">31 to 40</option>
                                    		<option value="41-50">41 to 50</option>
                                    		<option value="51-60">51 to 60</option>
                                    		<option value="61-70">61 to 70</option>
                                    	</select>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary" name="search" id ="search"><span class="glyphicon glyphicon-search"></span> Search</button>
                            <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                        </div>
                    </div>
                    </form>
                </div>
                </div>