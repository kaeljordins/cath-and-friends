<?php
$donor = $_POST['edit_id'];
$typeee = $_POST['types'];
$date = date("Y-m-d");
$patient = $_POST['patient-name'];
$gender = $_POST['gender'];
$birth = $_POST['birthdate'];
$age= $_POST['age'];
$city = $_POST['address'];                      
$contact= $_POST['contact'];          
$amount= $_POST['amount'];
$Email = $_POST['email'];
  $name = addslashes(file_get_contents($_FILES['image']['tmp_name']));
try {
         $sql = "INSERT INTO tbl_requestblood(DonorID, Req_Date, BloodType, Blood_Amount, Patient_Name, Gender, BirthDate, , Address, Contact_Number, Email, Doctor_Request) 
                VALUES ('$donor', '$date', '$typeee', '$amount', '$patient', '$gender', '$birth', '$city', '$contact', '$Email', '$name')";
                if ($mysqli->query($sql) === TRUE) {
                    echo '<script>alert("Successfully Added!");
                    location.href="\inventory.php";</script>' ;
                } else {
                    echo "Error: " . $sql . "<br>" . $mysqli->error;
                	}
                       	
} catch (Exception $e) {
        echo '<script>window.alert('.$e->getMessage().');</script>';
 }
?>