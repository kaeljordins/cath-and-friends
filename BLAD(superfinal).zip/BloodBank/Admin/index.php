<?php
session_start();
require '../db.php';
$myname = $_SESSION['id'];
if (!isset($_SESSION['id']) || $_SESSION['id'] == '')
{
    echo '<script>alert("Please login first!");
    location.href="../index.php";</script>' ;

  exit();
}
$firstname = $_SESSION['first'];
$lastname = $_SESSION['last'];



 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin - File Maintenance</title>
	<link rel="shortcut icon" href="../image/s.ico" />
	<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <!-- Optional theme -->
        <link rel="stylesheet" href="../css/bootstrap-theme.min.css">
        <!-- Loader -->
        <link rel="stylesheet" href="../css/loader.css">
        <script src="../js/jquery-1.12.4.js"></script>
        <link rel="stylesheet" type="text/css" href="dashboard/vendor/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
            $(document).ready(function() {
                $('#example').DataTable({

                });
            });
        </script>
        <link rel="stylesheet" href="../css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="../css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="../css/responsive.bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/jquery.dataTables.min.js"></script>
</head>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['register'])) { //user logging in

        require 'registration.php';
        
    }
    elseif (isset($_POST['register-donator'])) {
    	require 'donator-register.php';
    }
    elseif (isset($_POST['update'])) {
    	require 'update.php';
    }
    elseif (isset($_POST['update-donate'])) {
    	require 'update-donate.php';
    }
    elseif (isset($_POST['mail'])) {
        require 'mail.php';
    }
}
 ?>
<body onload="myFunction()" style="margin: 0;">
	<div class="dropdown">
                <button class="btn btn-primary dropdown-toggle btn-sm" type="button" data-toggle="dropdown"><span class='glyphicon glyphicon-user' aria-hidden='true'></span> <?php echo $firstname.' '.$lastname; ?>
                    <span class="caret"></span></button>
                <button class="btn btn-primary dropdown-toggle btn-sm" type="button"><span class='glyphicon glyphicon-eye-open' aria-hidden='true'></span><a href="requestor.php" style="text-decoration: none; color: white;"> View Requests</a></button>    
                <ul class="dropdown-menu">
                    <li><a href="#add" data-toggle="modal"><span class='glyphicon glyphicon-plus' aria-hidden='true'></span> Add Admin User</a></li>
                    <li><a href="#addDonator" data-toggle="modal"><span class='glyphicon glyphicon-plus' aria-hidden='true'></span> Add Donators</a></li>
                    <li><a href="../logout.php" data-toggle="modal"><span class='glyphicon glyphicon-log-out' aria-hidden='true'></span> Logout</a></li>
                </ul>
            </div><br>
	<table id="example" class="display nowrap" cellspacing="0" width="90%;">
		<thead>
			<th>Name</th>
            <th>Blood Type</th>
			<th>Email Address</th>
            <th>Chapter</th>
			<th>Address</th>
			<th>Contact Number</th>
			<th>Last Donation</th>
			<th>Action</th>
		</thead>
		<tfoot>
			<th>Name</th>
            <th>Blood Type</th>
			<th>Email Address</th>
            <th>Chapter</th>
			<th>Address</th>
			<th>Contact Number</th>
			<th>Last Donation</th>
			<th>Action</th>
		</tfoot>
		<tbody>
			<?php
			$sql = "SELECT tbl_users.UserID as UserID, tbl_users.Chapter, tbl_users.FirstName as First, tbl_users.LastName as Last, tbl_users.Birth_date as Birth, tbl_users.Email, tbl_users.Age as Age, tbl_users.Address as Address, tbl_users.BloodType, tbl_users.Contact as Contact, tbl_history.date_donated as LastDate from tbl_users join tbl_history on tbl_users.UserID = tbl_history.UserID";
			$result = $mysqli->query($sql);
			if ($result->num_rows > 0) {
				while ($row= $result->fetch_assoc()) {
					$id = $row['UserID'];
					$first = $row['First'];
					$last = $row['Last'];
					$age = $row['Age'];
					$email = $row['Email'];
					$adds = $row['Address'];
					$contact = $row['Contact'];
                    $chapters = $row['Chapter'];
					$lastdate = $row['LastDate'];
					$birth = $row['Birth'];
                    $type = $row['BloodType'];

					$name = $first.' '.$last;

					echo "<tr>
					<td>$name</td>
                    <td>$type</td>
					<td>$email</td>
                    <td>$chapters</td>
					<td>$adds</td>
					<td>$contact</td>
					<td>$lastdate</td>
					";
						?>
						<td>
							<a href="#donate<?php echo $id;?>" data-toggle="modal"><button type='button' class='btn btn-success btn-sm'><span class='glyphicon glyphicon-plus' aria-hidden='true'></span></button></a>
                            <a href="#edit<?php echo $id;?>" data-toggle="modal"><button type='button' class='btn btn-warning btn-sm'><span class='glyphicon glyphicon-edit' aria-hidden='true'></span></button></a>
                            <a href="#mail<?php echo $id;?>" data-toggle="modal"><button type='button' class='btn btn-warning btn-sm' title="Request Blood"><span class='glyphicon glyphicon-send' aria-hidden='true'></span></button></a>
                        </div>
						</td>

		  <div id="donate<?php echo $id; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Blood Donate</h4>
                                </div>
                                <div class="modal-body">
                                    <form method="post" class="form-horizontal" role="form">
                                    	 <input type="hidden" name="edit_id" value="<?php echo $id; ?>">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="item_Quantity">Donate Blood:</label>
                                            <div class="col-sm-4">
                                                <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Quantity" required min="1">
                                            </div>
                                        </div>
                                        <br><br><br>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" name="update-donate"><span class="glyphicon glyphicon-plus"></span> Update</button>
                                    <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
        </div>

<div id="mail<?php echo $id; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Confirm Request Blood to <?php echo $name; ?></h4>
                                </div>
                                <div class="modal-body">
                                    <form method="post" class="form-horizontal" role="form">
                                         <input type="hidden" name="edit_id" value="<?php echo $id; ?>">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="email">Send Email to:</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>" readonly>
                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" name="mail"><span class="glyphicon glyphicon-send"></span> Confirm</button>
                                    <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
        </div>

				<!--MODAL-->
	   <div id="edit<?php echo $id; ?>" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Update Record</h4>
                        </div>
                        <div class="modal-body">
                            <form method="post" class="form-horizontal" role="form">
                            <input type="hidden" name="edit_id" value="<?php echo $id; ?>">    
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="firstname">First Name:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $first; ?>" required>
                                    </div>
                                    <label class="control-label col-sm-2" for="lastname">Last Name:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $last;?>" required>
                                    </div>
                                </div><br><br>

                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="age">Age:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="age" name="age" value="<?php echo $age; ?>" required>
                                    </div>
                                    <label class="control-label col-sm-2" for="gender">Gender:</label>       
                                    <div class="col-sm-4">
                                        <select class="form-control" id="gender" name="gender">
                                    		<option value="Male">Male</option>
                                    		<option value="Female">Female</option>
                                    	</select>
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="birth">Birth Date:</label>       
                                    <div class="col-sm-4">
                                        <input type="date" class="form-control" id="birth" name="birthdate" value="<?php echo $birth; ?>" required>
                                        </div>  
                                    <label class="control-label col-sm-2" for="addr">City:</label>   

                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="addr" name="address" value="<?php echo $adds; ?>" required>
                                    </div>
                                </div><br><br>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="email">Email:</label>       
                                    <div class="col-sm-4">
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $email ?>" required>
                                    </div>
                                    <label class="control-label col-sm-2" for="contact">Contact Number:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="contact" name="contact" value="<?php echo $contact; ?>" required>
                                    </div>
                                </div><br><br>	
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary" name="update" id ="update"><span class="glyphicon glyphicon-plus"></span> Update</button>
                            <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                        </div>
                  
                    </form>
                      </div>
                </div>
               </div>

				<?php }
			}
				echo "</tr>"; ?>
		</tbody>
	</table>
  <!--MODAL-->
	   <div id="add" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Admin Registration</h4>
                        </div>
                        <div class="modal-body">
                            <form method="post" class="form-horizontal" role="form">    
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="firstname">First Name:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="lastname">Last Name:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" autofocus required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="age">Age:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="age" name="age" placeholder="Age" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="gender">Gender:</label>       
                                    <div class="col-sm-4">
                                        <select class="form-control" id="gender" name="gender" autofocus required>
                                    		<option value="Male">Male</option>
                                    		<option value="Female">Female</option>
                                    	</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="birth">Birth Date:</label>       
                                    <div class="col-sm-4">
                                        <input type="date" class="form-control" id="birth" name="birthdate">
                                    </div>
                                    <label class="control-label col-sm-2" for="addr">City:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="addr" name="address" placeholder="City" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="email">Email:</label>       
                                    <div class="col-sm-4">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="blood">Blood Type:</label>       
                                    <div class="col-sm-4">
                                        <select class="form-control" id="type" name="type">
											<option value="O-">O-</option>
											<option value="O+">O+</option>
											<option value="A-">A-</option>
											<option value="A+">A+</option>
											<option value="B-">B-</option>
											<option value="B+">B+</option>
											<option value="AB-">AB-</option>
											<option value="AB+">AB+</option>
										</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="passw">Password:</label>       
                                    <div class="col-sm-4">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="confirm">Confirm Password:</label>       
                                    <div class="col-sm-4">
                                        <input type="password" class="form-control" id="confirm_password" name="confirm" placeholder="Confirm Password" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="contact">Contact Number:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="contact" name="contact" placeholder="Contact Number" autofocus required>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary" name="register" id ="register"><span class="glyphicon glyphicon-plus"></span> Register</button>
                            <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                        </div>
                    </div>
                    </form>
                </div>
                </div>

                 <!--MODAL-->
	   <div id="addDonator" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Donator Registration</h4>
                        </div>
                        <div class="modal-body">
                            <form method="post" class="form-horizontal" role="form">    
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="firstname">First Name:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="lastname">Last Name:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" autofocus required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="age">Age:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="age" name="age" placeholder="Age" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="gender">Gender:</label>       
                                    <div class="col-sm-4">
                                        <select class="form-control" id="gender" name="gender" autofocus required>
                                    		<option value="Male">Male</option>
                                    		<option value="Female">Female</option>
                                    	</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="birth">Birth Date:</label>       
                                    <div class="col-sm-4">
                                        <input type="date" class="form-control" id="birth" name="birthdate">
                                    </div>                                    
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="chapter">Chapter:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="chapter" name="chapter" placeholder="Chapter">
                                    </div>
                                    <label class="control-label col-sm-2" for="address">Address:</label>       
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" id="address" name="address" placeholder="Address" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="email">Email:</label>       
                                    <div class="col-sm-4">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="blood">Blood Type:</label>       
                                    <div class="col-sm-4">
                                        <select class="form-control" id="type" name="type">
											<option value="O-">O-</option>
											<option value="O+">O+</option>
											<option value="A-">A-</option>
											<option value="A+">A+</option>
											<option value="B-">B-</option>
											<option value="B+">B+</option>
											<option value="AB-">AB-</option>
											<option value="AB+">AB+</option>
										</select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="passw">Password:</label>       
                                    <div class="col-sm-4">
                                        <input type="password" class="form-control" id="password1" name="password" placeholder="Password" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="confirm">Confirm Password:</label>       
                                    <div class="col-sm-4">
                                        <input type="password" class="form-control" id="confirm_password1" name="confirm" placeholder="Confirm Password" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2" for="contact">Contact Number:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="contact" name="contact" placeholder="Contact Number" autofocus required>
                                    </div>
                                    <label class="control-label col-sm-2" for="donated">Donated Blood:</label>       
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" id="donated" name="blood-count" placeholder="CC" autofocus required>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary" name="register-donator" id ="register"><span class="glyphicon glyphicon-plus"></span> Register</button>
                            <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                        </div>
                    </div>
                    </form>
                </div>
                </div>
</body>
</html>
<script src="../js/password.js"></script>
<script src="../js/password1.js"></script>