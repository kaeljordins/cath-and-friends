        <?php
        $email = $mysqli->escape_string($_POST['email']);
        $id = $mysqli->escape_string($_POST['edit_id']);


        $sql = $mysqli->query("SELECT * FROM tbl_users where UserID = '$id'");
             if ($sql->num_rows > 0) {
                 while ($row = $sql->fetch_assoc()) {
                    $first = $row['FirstName'];
                    $last = $row['LastName'];
}
                     $to = $email;
        $subject = 'Blood Donation';
        $message_body = '
        Hello '.$first.' '.$last.',

        We would like to invite you to come over at our office to Donate some blood.

        Be the Hero,  your drop of blood could save one of a thousand lives. Thank you so much!';

        mail( $to, $subject, $message_body );

         echo '<script>alert("Email sent!");
               location.href="\index.php";</script>';

             }
               ?> 